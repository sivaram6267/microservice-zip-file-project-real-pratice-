package com.lancesoft.kafka;

public class KafkaConstants {

	public static final String Topic= "demo-sbms-topic";
	public static final String GroupId= "group_customer";
	public static final String Host= "localhost:9092";
	
}
