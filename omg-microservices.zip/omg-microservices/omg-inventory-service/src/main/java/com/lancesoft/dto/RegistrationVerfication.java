package com.lancesoft.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@NoArgsConstructor
public class RegistrationVerfication {
private String phoneNumber;
}
